CONTEXT_PATH_DEFAULT = 'helper/default_convention.txt'
COMMIT_COLLECTION = 'commit_collection'